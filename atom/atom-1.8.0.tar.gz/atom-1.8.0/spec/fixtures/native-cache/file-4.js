module.exports = function () { return "file-4" }
